SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[View_COM_SKUOptionCategory_OptionCategory_Joined]
AS
SELECT        COM_SKUOptionCategory.SKUID, COM_SKUOptionCategory.CategoryID, COM_SKUOptionCategory.AllowAllOptions, 
                         COM_SKUOptionCategory.SKUCategoryID, COM_SKUOptionCategory.SKUCategoryOrder, COM_OptionCategory.CategoryDisplayName, 
                         COM_OptionCategory.CategoryName, COM_OptionCategory.CategorySelectionType, COM_OptionCategory.CategoryDefaultOptions, 
                         COM_OptionCategory.CategoryDescription, COM_OptionCategory.CategoryDefaultRecord, COM_OptionCategory.CategoryEnabled, 
                         COM_OptionCategory.CategoryGUID, COM_OptionCategory.CategoryLastModified, COM_OptionCategory.CategoryDisplayPrice, 
                         COM_OptionCategory.CategorySiteID, COM_OptionCategory.CategoryTextMaxLength, COM_OptionCategory.CategoryType,
						 COM_OptionCategory.CategoryTextMinLength, COM_OptionCategory.CategoryLiveSiteDisplayName
FROM            COM_OptionCategory INNER JOIN
                         COM_SKUOptionCategory ON COM_OptionCategory.CategoryID = COM_SKUOptionCategory.CategoryID


GO
