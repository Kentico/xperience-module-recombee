SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_ResourceString](
	[StringID] [int] IDENTITY(1,1) NOT NULL,
	[StringKey] [nvarchar](200) NOT NULL,
	[StringIsCustom] [bit] NOT NULL,
	[StringGUID] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_CMS_ResourceString] PRIMARY KEY CLUSTERED 
(
	[StringID] ASC
)
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_CMS_ResourceString_StringKey] ON [dbo].[CMS_ResourceString]
(
	[StringKey] ASC
)
GO
