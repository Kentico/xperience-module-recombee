SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Personas_PersonaContactHistory](
	[PersonaContactHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[PersonaContactHistoryPersonaID] [int] NULL,
	[PersonaContactHistoryDate] [date] NOT NULL,
	[PersonaContactHistoryContacts] [int] NOT NULL,
 CONSTRAINT [PK_Personas_PersonaContactHistory] PRIMARY KEY CLUSTERED 
(
	[PersonaContactHistoryID] ASC
)
)
GO
CREATE NONCLUSTERED INDEX [IX_Personas_PersonaContactHistoryPersonaID] ON [dbo].[Personas_PersonaContactHistory]
(
	[PersonaContactHistoryPersonaID] ASC
)
GO
ALTER TABLE [dbo].[Personas_PersonaContactHistory] ADD  CONSTRAINT [DEFAULT_Personas_PersonaContactHistory_PersonaContactHistoryDate]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [PersonaContactHistoryDate]
GO
ALTER TABLE [dbo].[Personas_PersonaContactHistory] ADD  CONSTRAINT [DEFAULT_Personas_PersonaContactHistory_PersonaContactHistoryContacts]  DEFAULT ((0)) FOR [PersonaContactHistoryContacts]
GO
ALTER TABLE [dbo].[Personas_PersonaContactHistory]  WITH CHECK ADD  CONSTRAINT [FK_Personas_PersonaContactHistory_Personas_Persona] FOREIGN KEY([PersonaContactHistoryPersonaID])
REFERENCES [dbo].[Personas_Persona] ([PersonaID])
GO
ALTER TABLE [dbo].[Personas_PersonaContactHistory] CHECK CONSTRAINT [FK_Personas_PersonaContactHistory_Personas_Persona]
GO
